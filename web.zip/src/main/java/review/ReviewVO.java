package review;

public class ReviewVO {

	private int rv_id, rv_readcnt, rv_no;
	private String rv_title, rv_content, rv_writer, rv_writedate, rv_modifydate, rv_filename, rv_filepath
					, shop, name, shop_tel, rv_type, shop_name;
	
	
	
	
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public String getShop_tel() {
		return shop_tel;
	}
	public void setShop_tel(String shop_tel) {
		this.shop_tel = shop_tel;
	}
	public String getRv_type() {
		return rv_type;
	}
	public void setRv_type(String rv_type) {
		this.rv_type = rv_type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRv_no() {
		return rv_no;
	}
	public void setRv_no(int rv_no) {
		this.rv_no = rv_no;
	}
	public int getRv_id() {
		return rv_id;
	}
	public void setRv_id(int rv_id) {
		this.rv_id = rv_id;
	}
	public int getRv_readcnt() {
		return rv_readcnt;
	}
	public void setRv_readcnt(int rv_readcnt) {
		this.rv_readcnt = rv_readcnt;
	}
	
	public String getRv_title() {
		return rv_title;
	}
	public void setRv_title(String rv_title) {
		this.rv_title = rv_title;
	}
	public String getRv_content() {
		return rv_content;
	}
	public void setRv_content(String rv_content) {
		this.rv_content = rv_content;
	}
	public String getRv_writer() {
		return rv_writer;
	}
	public void setRv_writer(String rv_writer) {
		this.rv_writer = rv_writer;
	}
	public String getRv_writedate() {
		return rv_writedate;
	}
	public void setRv_writedate(String rv_writedate) {
		this.rv_writedate = rv_writedate;
	}
	public String getRv_modifydate() {
		return rv_modifydate;
	}
	public void setRv_modifydate(String rv_modifydate) {
		this.rv_modifydate = rv_modifydate;
	}
	public String getRv_filename() {
		return rv_filename;
	}
	public void setRv_filename(String rv_filename) {
		this.rv_filename = rv_filename;
	}
	public String getRv_filepath() {
		return rv_filepath;
	}
	public void setRv_filepath(String rv_filepath) {
		this.rv_filepath = rv_filepath;
	}
	public String getShop() {
		return shop;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	
	
	
}
